# WakeLog — generatore APK Android

Questo progetto converte la web app WakeLog in un'app Android basata su WebView. Il workflow GitHub Actions crea un APK debug installabile e lo rende scaricabile come artifact.

## Build automatica
1. Crea un repository GitHub e carica **tutti i contenuti di questa cartella** (non solo lo ZIP), mantenendo le cartelle.
2. Apri la scheda **Actions** del repository.
3. Se richiesto, abilita le GitHub Actions.
4. Apri **Build WakeLog APK** → **Run workflow**.
5. Quando il workflow termina con successo, apri la sua esecuzione e scarica l'artifact **WakeLog-APK**.
6. Estrai lo ZIP dell'artifact sul telefono e installa `app-debug.apk`. Android potrebbe chiedere di autorizzare l'installazione da quella sorgente.

## Note
- Il file prodotto è un APK debug firmato automaticamente per installazione personale; non è una release Play Store.
- I dati restano nell'archivio locale dell'app/browser. Esporta regolarmente un backup prima di disinstallare o cambiare telefono.
- Le ricerche online richiedono connessione. Le fonti pubbliche possono essere incomplete.
